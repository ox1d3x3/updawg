from colorama import init
import os

if os.name == 'nt':
    init(convert=True)
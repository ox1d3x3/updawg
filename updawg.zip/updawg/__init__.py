version_info = (1,4)
version = '.'.join(str(c) for c in version_info)

base_directory = ''